



































# # Modules

# from folder1 import module1

# from folder1.module1 import sum2

# sum2()
# print(module1.square(2, 5))


# string = "a"
# string.upper()

# a = 10

# def walking():
#     print('Walking')

# def sleeping():
#     print('Slleping')

# walking()
# sleeping()


