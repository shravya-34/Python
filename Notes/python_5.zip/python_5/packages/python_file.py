# Builtin Modules
# import math
# print(math.pow(2, 4))

import pandas as pd

print("Hii")

def hello():
    print("Hello")

hello()

def numbers(a, b):
    div = a//b
    return div

