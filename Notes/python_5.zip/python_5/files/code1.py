# # file = open("hello.txt", 'r')

# # # print(file.name)
# # # print(file.readable())
# # # print(file.writable())

# # # print(file.read())

# # print(file.readline())
# # print(file.readline())
# # print(file.readlines())

# # file.close()
# # print(file.closed)

# with open("hello.txt", 'r') as file:
#     print(file.read())
#     print(file.closed)

# print(file.closed)


f2 = open("hii1.txt", 'x')
f2.write("Helllllllllllllllooooooooo")
# f2.seek(1)
# text = f2.read()
# print(text)

# f3 = open("hello.txt", 'a')
# f3.write("Helllllllllllllllooooooooo")

