from packages import python_file as pf

from packages.python_file import numbers, hello

pf.hello()

div = pf.numbers(20, 10)

print(div)

print(numbers(100, 20))

hello()